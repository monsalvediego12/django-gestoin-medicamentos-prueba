from gest_prueba.models import Medicamentos, Tratamientos, Enfermedades
from gest_prueba.serializers import (
    MedicamentosSerializer,
    TratamientosSerializer,
    EnfermedadesSerializer,
)
from rest_framework import viewsets
from rest_framework.response import Response
from django.db.models import F


class MedicamentosViewSet(viewsets.ModelViewSet):

    queryset = Medicamentos.objects.all()
    serializer_class = MedicamentosSerializer
    permission_classes = []


class TratamientosViewSet(viewsets.ModelViewSet):

    queryset = Tratamientos.objects.all()
    serializer_class = TratamientosSerializer
    permission_classes = []


class EnfermedadesViewSet(viewsets.ModelViewSet):

    queryset = Enfermedades.objects.all()
    serializer_class = EnfermedadesSerializer
    permission_classes = []


class QuerysViewSet(viewsets.ViewSet):
    """
    A simple ViewSet for listing or retrieving users.
    """

    def s1(self, request):
        res = {
            "title": "Obtener la lista de todas las enfermedades que tengan más de 6 medicamentos diferentes indicados para su tratamiento.",
            "items": [],
        }
        queryset = (
            Enfermedades.objects.filter(tratamientos__medicamentos__gt=6)
            .distinct()
            .all()
        )
        res["items"] = normalizeQuerysetJson(queryset)
        return Response(res)

    def s2(self, request):
        res = {
            "title": "Obtener la lista de todas las enfermedades que tengan entre 7 y 12 medicamentos diferentes indicados y cuenten con al menos 3 tratamientos posibles.",
            "items": [],
        }
        queryset = (
            Enfermedades.objects.filter(tratamientos__medicamentos__gt=6)
            .distinct()
            .all()
        )
        res["items"] = normalizeQuerysetJson(queryset)
        return Response(res)

    def s3(self, request):
        res = {
            "title": "Obtener la lista de medicamentos que estén indicados en el tratamiento de menos de 2 enfermedades.",
            "items": [],
        }
        queryset = (
            Medicamentos.objects.filter(trat_medicamento__enfermedad_tratamiento__lt=2)
            .distinct().all()
        )

        for item in queryset:
            try:
                for itemTratamiendo in item.trat_medicamento.values():
                    print(
                        "222",
                        Tratamientos.objects.get(pk=itemTratamiendo["id"])
                        .enfermedad_tratamiento.values()
                        .distinct(),
                    )
            except Exception as e:
                print("eee", e)
                pass

        res["items"] = normalizeQuerysetJson(queryset)

        return Response(res)

    def s4(self, request):
        res = {
            "title": "Mostrar la cantidad de tratamientos y medicamentos diferentes indicados a cada enfermedad, presentando al menos el nombre de la enfermedad y los valores solicitados.",
            "items": [],
        }
        queryset = Enfermedades.objects.all()

        for item in queryset:
            dataItem = {
                "nombre": item.name,
                "cantidad_tratamientos": 0,
                "cantidad_medicamentos": 0,
            }
            try:
                dataItem["cantidad_tratamientos"] = len(item.tratamientos.values())

                medicamentos = Medicamentos.objects.filter(
                    trat_medicamento__in=[x["id"] for x in item.tratamientos.values()]
                ).all()
                dataItem["cantidad_medicamentos"] = (
                    dataItem["cantidad_medicamentos"] + medicamentos.count()
                )

            except Exception as e:
                print("eee", e)

            res["items"].append(dataItem)

        return Response(res)


def normalizeQuerysetJson(queryset):
    data = []
    try:
        if queryset.exists():
            for item in queryset:
                data.append({"id": item.id, "name": item.name})
    except:
        pass
    return data
