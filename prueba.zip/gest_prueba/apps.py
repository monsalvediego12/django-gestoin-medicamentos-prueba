from django.apps import AppConfig


class GestPruebaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gest_prueba'
